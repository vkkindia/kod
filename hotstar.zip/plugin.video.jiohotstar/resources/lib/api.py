import requests
import time
import hashlib
import hmac
import uuid

class JioHotstarAPI:
    def __init__(self):
        # In 2026, jiostar.com is the unified domain
        self.base_url = "https://api.jiostar.com/v1"
        self.fallback_url = "https://api.hotstar.com"
        self.encryption_key = b'\x05\xfc\x1a\x01\xca\xc9\x4b\xc4\x12\xfc\x53\x12\x07\x75\xf9\xee'
        self.device_id = str(uuid.uuid4())

    def _generate_auth_header(self):
        st = int(time.time())
        exp = st + 6000
        auth_str = f'st={st}~exp={exp}~acl=/*'
        signature = hmac.new(self.encryption_key, auth_str.encode(), hashlib.sha256).hexdigest()
        return f"{auth_str}~hmac={signature}"

    def get_home(self):
        # Try unified jiostar endpoint first, then fallback
        endpoints = [f"{self.base_url}/content/home", f"{self.fallback_url}/oapi/v1/pages/home"]
        headers = {
            'hotstarauth': self._generate_auth_header(),
            'x-country-code': 'IN',
            'x-platform-code': 'PWA',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        for endpoint in endpoints:
            try:
                response = requests.get(endpoint, headers=headers)
                if response.status_code == 200:
                    data = response.json()
                    # Unified API might have different structure, handle both
                    if 'body' in data:
                        return data.get('body', {}).get('results', {}).get('items', [])
                    return data.get('results', [])
            except Exception:
                continue
        return []

    def get_playback_info(self, content_id):
        endpoints = [f"{self.base_url}/playback/manifest?id={content_id}", f"{self.fallback_url}/play/v1/playback/content/{content_id}"]
        headers = {
            'hotstarauth': self._generate_auth_header(),
            'x-country-code': 'IN',
            'x-platform-code': 'PWA'
        }
        
        for endpoint in endpoints:
            try:
                response = requests.get(endpoint, headers=headers)
                if response.status_code == 200:
                    return response.json()
            except Exception:
                continue
        return None
