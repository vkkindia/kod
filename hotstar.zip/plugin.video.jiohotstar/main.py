import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
from resources.lib.api import JioHotstarAPI

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def list_home():
    api = JioHotstarAPI()
    items = api.get_home()
    
    for item in items:
        title = item.get('title')
        content_id = item.get('contentId')
        image = item.get('images', {}).get('v')
        
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({"icon": image, "thumb": image})
        
        if item.get('type') == 'COLLECTION':
            url = f"{BASE_URL}?action=list&id={content_id}"
            is_folder = True
        else:
            url = f"{BASE_URL}?action=play&id={content_id}"
            is_folder = False
            list_item.setProperty('IsPlayable', 'true')
            
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(content_id):
    api = JioHotstarAPI()
    playback_info = api.get_playback_info(content_id)
    
    if not playback_info:
        xbmcgui.Dialog().ok("Error", "Could not fetch playback info")
        return

    # In a real scenario, you'd extract the HLS/MPD URL and DRM tokens
    stream_url = playback_info.get('body', {}).get('results', {}).get('playback_url')
    
    if not stream_url:
        xbmcgui.Dialog().ok("Error", "No stream URL found")
        return

    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls') # or mpd
    
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    
    if action == 'play':
        play_video(params.get('id'))
    else:
        list_home()
