import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib.api import JioTVAPI

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def list_channels():
    mobile = ADDON.getSetting("mobile")
    sso_token = ADDON.getSetting("sso_token")
    
    if not sso_token:
        list_item = xbmcgui.ListItem(label="[COLOR yellow]Login to JioTV[/COLOR]")
        url = f"{BASE_URL}?action=login"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api = JioTVAPI(mobile)
    channels = api.get_channels(sso_token)
    
    if not channels:
        xbmcgui.Dialog().ok("JioTV", "Failed to fetch channels. Try logging in again.")
        ADDON.setSetting("sso_token", "")
        return

    for channel in channels:
        name = channel.get("channel_name")
        channel_id = channel.get("channel_id")
        icon = f"https://jiotv.live.cdn.jio.com/channels/logo/{channel_id}.png"
        
        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({"icon": icon, "thumb": icon})
        list_item.setProperty('IsPlayable', 'true')
        
        play_url = f"{BASE_URL}?action=play&id={channel_id}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=play_url, listitem=list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_channel(channel_id):
    sso_token = ADDON.getSetting("sso_token")
    stream_url = f"http://jiotv.live.cdn.jio.com/{channel_id}/{channel_id}_800.m3u8?ssotoken={sso_token}"
    
    user_agent = "plaYtv/7.1.5 (Linux;Android 9) ExoPlayerLib/2.11.7"
    
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    list_item.setProperty('inputstream.adaptive.stream_headers', f'User-Agent={user_agent}&partner=jiotvvod')
    
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

def login():
    mobile = ADDON.getSetting("mobile")
    if not mobile:
        mobile = xbmcgui.Dialog().numeric(0, "Enter Jio Mobile Number")
        if not mobile: return
        ADDON.setSetting("mobile", mobile)
    
    api = JioTVAPI(mobile)
    success, msg = api.send_otp()
    if not success:
        xbmcgui.Dialog().ok("Error", f"Failed to send OTP: {msg}")
        return

    otp = xbmcgui.Dialog().numeric(0, "Enter OTP received via SMS")
    if not otp: return
    
    success, token = api.verify_otp(otp)
    if success:
        ADDON.setSetting("sso_token", token)
        xbmcgui.Dialog().notification("JioTV", "Login Successful!", xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    else:
        xbmcgui.Dialog().ok("Error", f"Login failed: {token}")

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    
    if action == 'play':
        play_channel(params.get('id'))
    elif action == 'login':
        login()
    else:
        list_channels()
