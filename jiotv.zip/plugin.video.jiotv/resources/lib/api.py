import requests
import json
import time

class JioTVAPI:
    def __init__(self, mobile=None):
        self.mobile = mobile
        self.session = requests.Session()
        self.api_key = "l7xx75e822925f184370b2e25170c5d5820a"
        self.headers = {
            "x-api-key": self.api_key,
            "User-Agent": "JioTV",
            "os": "android",
            "devicetype": "phone",
            "appname": "RJIL_JioTV",
            "versioncode": "396"
        }

    def send_otp(self):
        if not self.mobile:
            return False, "Mobile number not provided"
        
        url = "https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/send"
        payload = {
            "number": self.mobile,
            "otp_delivery_mode": "sms"
        }
        try:
            response = self.session.post(url, headers=self.headers, json=payload)
            if response.status_code == 204 or response.status_code == 200:
                return True, "OTP Sent"
            return False, response.text
        except Exception as e:
            return False, str(e)

    def verify_otp(self, otp):
        if not self.mobile or not otp:
            return False, "Mobile or OTP missing"
        
        url = "https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/verify"
        payload = {
            "number": self.mobile,
            "otp": otp,
            "otp_delivery_mode": "sms"
        }
        try:
            response = self.session.post(url, headers=self.headers, json=payload)
            if response.status_code == 200:
                data = response.json()
                return True, data.get("ssoToken")
            return False, response.text
        except Exception as e:
            return False, str(e)

    def get_channels(self, sso_token):
        url = "https://jiotvapi.cdn.jio.com/apis/v3.1/getMobileChannelList/get/?langId=6&os=android&devicetype=phone&usertype=JIO&version=389"
        headers = self.headers.copy()
        headers["ssotoken"] = sso_token
        try:
            response = self.session.get(url, headers=headers)
            if response.status_code == 200:
                return response.json().get("result", [])
            return []
        except Exception:
            return []
